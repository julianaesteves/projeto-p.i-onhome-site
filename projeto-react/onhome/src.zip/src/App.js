
import './App.css';
import Configuracoes from './pages/Dashboard/Configuracoes/Index';
import Home from './pages/Dashboard/Home/';
import InitialPage from './pages/InitialPage/InitialPage';
import Login from './pages/Login/Index';
import Usuarios from './pages/Dashboard/Usuarios/Index';

function App() {
  return (
    <div className="App">
      <Home />
    </div>
  );
}

export default App;